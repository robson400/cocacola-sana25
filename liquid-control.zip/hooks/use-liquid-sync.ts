"use client"

import { useState, useEffect, useCallback, useRef } from "react"

interface LiquidState {
  level: number
  lastUpdate: number
}

interface UseLiquidSyncReturn {
  level: number
  isConnected: boolean
  isLoading: boolean
  error: string | null
  updateLevel: (newLevel: number) => Promise<boolean>
  retry: () => void
}

export function useLiquidSync(pollInterval = 500): UseLiquidSyncReturn {
  const [level, setLevel] = useState(50)
  const [isConnected, setIsConnected] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const intervalRef = useRef<NodeJS.Timeout | null>(null)
  const lastUpdateRef = useRef<number>(0)

  const fetchState = useCallback(async () => {
    try {
      const response = await fetch("/api/liquid", {
        method: "GET",
        cache: "no-cache",
      })

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`)
      }

      const result = await response.json()

      if (result.success) {
        // Only update if data is newer
        if (result.data.lastUpdate > lastUpdateRef.current) {
          setLevel(result.data.level)
          lastUpdateRef.current = result.data.lastUpdate
        }
        setIsConnected(true)
        setError(null)
      } else {
        throw new Error(result.error || "Unknown error")
      }
    } catch (err) {
      console.error("Fetch error:", err)
      setIsConnected(false)
      setError(err instanceof Error ? err.message : "Network error")
    } finally {
      setIsLoading(false)
    }
  }, [])

  const updateLevel = useCallback(async (newLevel: number): Promise<boolean> => {
    try {
      const response = await fetch("/api/liquid", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ level: newLevel }),
      })

      const result = await response.json()

      if (result.success) {
        setLevel(result.data.level)
        lastUpdateRef.current = result.data.lastUpdate
        setIsConnected(true)
        setError(null)
        return true
      } else {
        setError(result.error || "Update failed")
        return false
      }
    } catch (err) {
      console.error("Update error:", err)
      setError(err instanceof Error ? err.message : "Update failed")
      setIsConnected(false)
      return false
    }
  }, [])

  const retry = useCallback(() => {
    setError(null)
    setIsLoading(true)
    fetchState()
  }, [fetchState])

  useEffect(() => {
    // Initial fetch
    fetchState()

    // Start polling
    intervalRef.current = setInterval(fetchState, pollInterval)

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
      }
    }
  }, [fetchState, pollInterval])

  return {
    level,
    isConnected,
    isLoading,
    error,
    updateLevel,
    retry,
  }
}
