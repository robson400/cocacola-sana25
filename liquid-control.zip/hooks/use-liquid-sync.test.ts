import { renderHook, act } from "@testing-library/react"
import { useLiquidSync } from "./use-liquid-sync"
import jest from "jest"

// Mock fetch
global.fetch = jest.fn()

describe("useLiquidSync", () => {
  beforeEach(() => {
    jest.clearAllMocks()
    jest.useFakeTimers()
  })

  afterEach(() => {
    jest.useRealTimers()
  })

  test("should initialize with loading state", () => {
    const { result } = renderHook(() => useLiquidSync(1000))

    expect(result.current.isLoading).toBe(true)
    expect(result.current.level).toBe(50)
    expect(result.current.isConnected).toBe(false)
  })

  test("should fetch initial state successfully", async () => {
    ;(fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: async () => ({
        success: true,
        data: { level: 75, lastUpdate: Date.now() },
      }),
    })

    const { result } = renderHook(() => useLiquidSync(1000))

    await act(async () => {
      jest.runOnlyPendingTimers()
    })

    expect(result.current.level).toBe(75)
    expect(result.current.isConnected).toBe(true)
    expect(result.current.isLoading).toBe(false)
  })

  test("should handle fetch errors", async () => {
    ;(fetch as jest.Mock).mockRejectedValueOnce(new Error("Network error"))

    const { result } = renderHook(() => useLiquidSync(1000))

    await act(async () => {
      jest.runOnlyPendingTimers()
    })

    expect(result.current.isConnected).toBe(false)
    expect(result.current.error).toBe("Network error")
  })

  test("should update level successfully", async () => {
    ;(fetch as jest.Mock)
      .mockResolvedValueOnce({
        ok: true,
        json: async () => ({ success: true, data: { level: 50, lastUpdate: Date.now() } }),
      })
      .mockResolvedValueOnce({
        ok: true,
        json: async () => ({ success: true, data: { level: 80, lastUpdate: Date.now() } }),
      })

    const { result } = renderHook(() => useLiquidSync(1000))

    await act(async () => {
      const success = await result.current.updateLevel(80)
      expect(success).toBe(true)
    })

    expect(result.current.level).toBe(80)
  })
})
