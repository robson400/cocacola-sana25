import { liquidState } from "@/lib/liquid-state"
import { type NextRequest, NextResponse } from "next/server"

export const dynamic = "force-dynamic"
export const runtime = "nodejs"

export async function GET() {
  try {
    const state = liquidState.getState()
    return NextResponse.json({
      success: true,
      data: state,
    })
  } catch (error) {
    console.error("GET /api/liquid error:", error)
    return NextResponse.json({ success: false, error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { level } = body

    if (typeof level !== "number") {
      return NextResponse.json({ success: false, error: "Level must be a number" }, { status: 400 })
    }

    const success = liquidState.setLevel(level)

    if (!success) {
      return NextResponse.json({ success: false, error: "Level must be between 0 and 100" }, { status: 400 })
    }

    return NextResponse.json({
      success: true,
      data: liquidState.getState(),
    })
  } catch (error) {
    console.error("POST /api/liquid error:", error)
    return NextResponse.json({ success: false, error: "Internal server error" }, { status: 500 })
  }
}
