import { GET, POST } from "./route"
import { liquidState } from "@/lib/liquid-state"

// Mock NextRequest
const createMockRequest = (body: any) =>
  ({
    json: async () => body,
  }) as any

describe("/api/liquid", () => {
  beforeEach(() => {
    liquidState.setLevel(50)
  })

  describe("GET", () => {
    test("should return current state", async () => {
      const response = await GET()
      const data = await response.json()

      expect(data.success).toBe(true)
      expect(data.data.level).toBe(50)
      expect(typeof data.data.lastUpdate).toBe("number")
    })
  })

  describe("POST", () => {
    test("should update level with valid data", async () => {
      const request = createMockRequest({ level: 75 })
      const response = await POST(request)
      const data = await response.json()

      expect(data.success).toBe(true)
      expect(data.data.level).toBe(75)
      expect(liquidState.getLevel()).toBe(75)
    })

    test("should reject invalid level", async () => {
      const request = createMockRequest({ level: 150 })
      const response = await POST(request)
      const data = await response.json()

      expect(data.success).toBe(false)
      expect(response.status).toBe(400)
      expect(liquidState.getLevel()).toBe(50) // Unchanged
    })

    test("should reject non-number level", async () => {
      const request = createMockRequest({ level: "invalid" })
      const response = await POST(request)
      const data = await response.json()

      expect(data.success).toBe(false)
      expect(response.status).toBe(400)
    })
  })
})
