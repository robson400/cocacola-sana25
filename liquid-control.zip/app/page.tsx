"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Smartphone, Monitor } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-white flex items-center justify-center">
      <div className="text-center space-y-8 max-w-2xl mx-auto px-4">
        <div className="space-y-4">
          {/* LOGO – troque /logo.png pelo seu arquivo quando quiser */}
          <div className="inline-flex items-center justify-center mb-4">
            <img src="/logo.png" alt="Logo da Coca-Cola" className="h-16 w-auto object-contain" />
          </div>
          <h1 className="text-4xl font-bold text-red-600 mb-4">Sistema de Controle de Líquido</h1>
          <p className="text-gray-600 text-lg">Controle em tempo real da visualização de líquido</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-white rounded-xl shadow-lg p-6 border border-red-100">
            <div className="flex items-center justify-center w-12 h-12 bg-red-100 rounded-lg mb-4 mx-auto">
              <Smartphone className="w-6 h-6 text-red-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">Tela de Controle</h3>
            <p className="text-gray-600 mb-4 text-sm">Use no celular ou tablet para controlar o nível do líquido</p>
            <Link href="/control">
              <Button className="w-full bg-red-600 hover:bg-red-700 text-white">Abrir Controle</Button>
            </Link>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6 border border-red-100">
            <div className="flex items-center justify-center w-12 h-12 bg-red-100 rounded-lg mb-4 mx-auto">
              <Monitor className="w-6 h-6 text-red-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">Tela de Visualização</h3>
            <p className="text-gray-600 mb-4 text-sm">Use no computador ou TV para visualizar a animação</p>
            <Link href="/display">
              <Button className="w-full bg-red-500 hover:bg-red-600 text-white">Abrir Visualização</Button>
            </Link>
          </div>
        </div>
        <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
          <h4 className="font-semibold text-blue-800 mb-2">💡 Como usar:</h4>
          <ol className="text-blue-700 text-sm text-left space-y-1">
            <li>
              1. Abra a <strong>Tela de Visualização</strong> no computador/TV
            </li>
            <li>
              2. Abra a <strong>Tela de Controle</strong> no celular/tablet
            </li>
            <li>3. Mova o slider e veja a animação reagir em tempo real!</li>
          </ol>
        </div>
        <div>
          <p>
            Sistema feito por{" "}
            <a href="http://rwstudio.digital/" target="_blank" rel="noreferrer">
              <strong>rwstudio.digital</strong>
            </a>
          </p>
        </div>
      </div>
    </div>
  )
}
