"use client"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Wifi, WifiOff, AlertCircle, RotateCcw } from "lucide-react"
import { useLiquidSync } from "@/hooks/use-liquid-sync"

export default function DisplayPage() {
  const { level, isConnected, isLoading, error, retry } = useLiquidSync(300) // Faster polling for display

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-center text-white">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-red-500 mx-auto mb-4"></div>
          <p className="text-xl">Conectando ao sistema...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-900 relative overflow-hidden">
      {/* Header com controles */}
      <div className="absolute top-4 left-4 right-4 z-20 flex justify-between items-center">
        <Link href="/">
          <Button variant="ghost" className="text-white hover:bg-white/10">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar
          </Button>
        </Link>

        <div className="flex items-center space-x-4">
          <div
            className={`flex items-center space-x-2 px-3 py-1 rounded-full text-sm ${
              isConnected
                ? "bg-green-500/20 text-green-400 border border-green-500/30"
                : "bg-red-500/20 text-red-400 border border-red-500/30"
            }`}
          >
            {isConnected ? (
              <>
                <Wifi className="w-4 h-4" />
                <span>Online</span>
              </>
            ) : (
              <>
                <WifiOff className="w-4 h-4" />
                <span>Offline</span>
              </>
            )}
          </div>

          <div className="bg-black/50 backdrop-blur-sm rounded-lg px-4 py-2 border border-white/10">
            <div className="text-white text-xl font-bold">{level}%</div>
          </div>

          {error && (
            <Button onClick={retry} variant="ghost" size="sm" className="text-white hover:bg-white/10">
              <RotateCcw className="w-4 h-4" />
            </Button>
          )}
        </div>
      </div>

      {/* Error banner */}
      {error && (
        <div className="absolute top-20 left-4 right-4 z-20">
          <div className="bg-red-500/20 border border-red-500/30 rounded-lg p-3 flex items-center text-red-400">
            <AlertCircle className="w-4 h-4 mr-2" />
            <span className="text-sm">{error}</span>
          </div>
        </div>
      )}

      {/* Container do líquido */}
      <div className="absolute inset-0 flex items-end">
        <div
          className="w-full bg-gradient-to-t from-red-700 via-red-600 to-red-500 transition-all duration-700 ease-out relative overflow-hidden"
          style={{
            height: `${level}%`,
            minHeight: level > 0 ? "2px" : "0px",
          }}
        >
          {/* Efeito de ondas na superfície */}
          {level > 0 && (
            <div className="absolute top-0 left-0 w-full h-12 bg-gradient-to-b from-red-400 to-transparent">
              <div className="wave-animation absolute top-0 left-0 w-full h-full">
                <div className="wave wave1"></div>
                <div className="wave wave2"></div>
                <div className="wave wave3"></div>
              </div>
            </div>
          )}

          {/* Brilho do líquido */}
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent animate-pulse"></div>

          {/* Reflexos */}
          <div className="absolute top-0 left-1/4 w-1/2 h-full bg-gradient-to-b from-white/20 to-transparent opacity-30"></div>

          {/* Bolhas */}
          {level > 5 && (
            <div className="bubbles">
              <div className="bubble bubble1"></div>
              <div className="bubble bubble2"></div>
              <div className="bubble bubble3"></div>
              <div className="bubble bubble4"></div>
              <div className="bubble bubble5"></div>
              <div className="bubble bubble6"></div>
            </div>
          )}
        </div>
      </div>

      {/* Marcações de nível centralizadas */}
      <div className="absolute inset-0 flex flex-col justify-between py-12 text-white/60 text-lg font-mono pointer-events-none">
        {/* 100% */}
        <div className="flex flex-col items-center">
          <div className="text-2xl font-bold mb-2">100%</div>
          <div className="w-full h-px bg-white/40"></div>
        </div>

        {/* 75% */}
        <div className="flex flex-col items-center">
          <div className="text-xl font-bold mb-2">75%</div>
          <div className="w-full h-px bg-white/30"></div>
        </div>

        {/* 50% */}
        <div className="flex flex-col items-center">
          <div className="text-2xl font-bold mb-2">50%</div>
          <div className="w-full h-px bg-white/40"></div>
        </div>

        {/* 25% */}
        <div className="flex flex-col items-center">
          <div className="text-xl font-bold mb-2">25%</div>
          <div className="w-full h-px bg-white/30"></div>
        </div>

        {/* 0% */}
        <div className="flex flex-col items-center">
          <div className="text-2xl font-bold mb-2">0%</div>
          <div className="w-full h-px bg-white/40"></div>
        </div>
      </div>

      {/* Instruções quando desconectado */}
      {!isConnected && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm">
          <div className="text-center text-white p-8 rounded-lg bg-black/30 border border-white/10">
            <WifiOff className="w-12 h-12 mx-auto mb-4 text-red-400" />
            <h3 className="text-xl font-semibold mb-2">Conexão Perdida</h3>
            <p className="text-white/70 mb-4">Tentando reconectar automaticamente...</p>
            <Button
              onClick={retry}
              variant="outline"
              className="text-white border-white/30 hover:bg-white/10 bg-transparent"
            >
              Tentar Agora
            </Button>
          </div>
        </div>
      )}

      <style jsx>{`
        .wave-animation {
          position: relative;
        }
        
        .wave {
          position: absolute;
          top: 0;
          left: 0;
          width: 200%;
          height: 100%;
          background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
          border-radius: 0 0 50% 50%;
          animation: wave 4s ease-in-out infinite;
        }
        
        .wave1 {
          animation-delay: 0s;
        }
        
        .wave2 {
          animation-delay: 1.3s;
          opacity: 0.8;
        }
        
        .wave3 {
          animation-delay: 2.6s;
          opacity: 0.6;
        }
        
        @keyframes wave {
          0%, 100% {
            transform: translateX(-50%) translateY(0px);
          }
          50% {
            transform: translateX(-50%) translateY(-15px);
          }
        }
        
        .bubbles {
          position: absolute;
          bottom: 0;
          left: 0;
          width: 100%;
          height: 100%;
          pointer-events: none;
        }
        
        .bubble {
          position: absolute;
          background: rgba(255, 255, 255, 0.4);
          border-radius: 50%;
          animation: bubble 6s infinite ease-in-out;
        }
        
        .bubble1 {
          width: 6px;
          height: 6px;
          left: 15%;
          animation-delay: 0s;
        }
        
        .bubble2 {
          width: 10px;
          height: 10px;
          left: 35%;
          animation-delay: 1.5s;
        }
        
        .bubble3 {
          width: 4px;
          height: 4px;
          left: 65%;
          animation-delay: 3s;
        }
        
        .bubble4 {
          width: 8px;
          height: 8px;
          left: 85%;
          animation-delay: 4.5s;
        }
        
        .bubble5 {
          width: 12px;
          height: 12px;
          left: 50%;
          animation-delay: 2s;
        }
        
        .bubble6 {
          width: 5px;
          height: 5px;
          left: 25%;
          animation-delay: 3.5s;
        }
        
        @keyframes bubble {
          0% {
            bottom: 0;
            opacity: 0;
            transform: scale(0.3);
          }
          10% {
            opacity: 1;
            transform: scale(1);
          }
          90% {
            opacity: 1;
          }
          100% {
            bottom: 100%;
            opacity: 0;
            transform: scale(0.3);
          }
        }
      `}</style>
    </div>
  )
}
