"use client"

import { useState } from "react"
import { Slider } from "@/components/ui/slider"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowLeft, Droplets, Wifi, WifiOff, AlertCircle, RotateCcw } from "lucide-react"
import { useLiquidSync } from "@/hooks/use-liquid-sync"

export default function ControlPage() {
  const { level, isConnected, isLoading, error, updateLevel, retry } = useLiquidSync(500)
  const [localValue, setLocalValue] = useState([level])
  const [isUpdating, setIsUpdating] = useState(false)

  // Sync local value with remote level
  useState(() => {
    setLocalValue([level])
  })

  const handleSliderChange = async (newValue: number[]) => {
    setLocalValue(newValue)
    setIsUpdating(true)

    const success = await updateLevel(newValue[0])
    if (!success) {
      // Revert on failure
      setLocalValue([level])
    }

    setIsUpdating(false)
  }

  const handleQuickSet = async (newValue: number) => {
    setIsUpdating(true)
    const success = await updateLevel(newValue)
    if (success) {
      setLocalValue([newValue])
    }
    setIsUpdating(false)
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 to-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Conectando ao servidor...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-white">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center mb-6">
          <Link href="/">
            <Button variant="ghost" className="text-red-600 hover:text-red-700">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar
            </Button>
          </Link>

          <div className="flex items-center space-x-2">
            <div
              className={`flex items-center space-x-2 px-3 py-1 rounded-full text-sm ${
                isConnected ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
              }`}
            >
              {isConnected ? (
                <>
                  <Wifi className="w-4 h-4" />
                  <span>Online</span>
                </>
              ) : (
                <>
                  <WifiOff className="w-4 h-4" />
                  <span>Offline</span>
                </>
              )}
            </div>

            {error && (
              <Button
                onClick={retry}
                variant="outline"
                size="sm"
                className="text-red-600 border-red-200 hover:bg-red-50 bg-transparent"
              >
                <RotateCcw className="w-4 h-4" />
              </Button>
            )}
          </div>
        </div>

        <div className="max-w-lg mx-auto">
          <div className="bg-white rounded-2xl shadow-xl p-6 border border-red-100">
            <div className="text-center mb-6">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-red-100 rounded-full mb-4">
                <Droplets className="w-8 h-8 text-red-600" />
              </div>
              <h1 className="text-2xl font-bold text-red-600 mb-2">Controle de Nível</h1>
              <p className="text-gray-600 text-sm">Sistema robusto com polling</p>
            </div>

            {error && (
              <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-center">
                <AlertCircle className="w-4 h-4 text-red-600 mr-2" />
                <span className="text-red-700 text-sm">{error}</span>
              </div>
            )}

            <div className="space-y-6">
              <div className="text-center">
                <div className="text-5xl font-bold text-red-600 mb-2">{isUpdating ? localValue[0] : level}%</div>
                <div className="text-gray-500 text-sm">{isUpdating ? "Atualizando..." : "Nível atual"}</div>
              </div>

              <div className="px-2">
                <Slider
                  value={localValue}
                  onValueChange={handleSliderChange}
                  max={100}
                  min={0}
                  step={5}
                  className="w-full"
                  disabled={!isConnected || isUpdating}
                />
                <div className="flex justify-between text-xs text-gray-500 mt-2">
                  <span>0%</span>
                  <span>50%</span>
                  <span>100%</span>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <Button
                  onClick={() => handleQuickSet(0)}
                  variant="outline"
                  className="border-red-200 text-red-600 hover:bg-red-50 text-sm py-2"
                  disabled={!isConnected || isUpdating}
                >
                  Vazio
                </Button>
                <Button
                  onClick={() => handleQuickSet(50)}
                  variant="outline"
                  className="border-red-200 text-red-600 hover:bg-red-50 text-sm py-2"
                  disabled={!isConnected || isUpdating}
                >
                  Meio
                </Button>
                <Button
                  onClick={() => handleQuickSet(100)}
                  variant="outline"
                  className="border-red-200 text-red-600 hover:bg-red-50 text-sm py-2"
                  disabled={!isConnected || isUpdating}
                >
                  Cheio
                </Button>
              </div>

              <div className="text-center">
                <Link href="/display" target="_blank">
                  <Button className="bg-red-600 hover:bg-red-700 text-white px-6 py-2 text-sm" disabled={!isConnected}>
                    Abrir Visualização
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
