type Subscriber = (data: string) => void

/* ---------- Estado global (singleton) ---------- */
let level = 50
let subscribers: Subscriber[] = []

export function getLevel() {
  return level
}

export function setLevel(newLevel: number) {
  level = Math.max(0, Math.min(100, newLevel))
  broadcast({ level })
}

export function subscribe(fn: Subscriber) {
  subscribers.push(fn)
  // Cancela a inscrição
  return () => {
    subscribers = subscribers.filter((s) => s !== fn)
  }
}

function broadcast(payload: unknown) {
  const msg = `data: ${JSON.stringify(payload)}\n\n`
  subscribers.forEach((fn) => {
    try {
      fn(msg)
    } catch {
      /* cliente desconectado, será limpo no unsubscribe */
    }
  })
}
