import { liquidState } from "./liquid-state"

describe("LiquidState", () => {
  beforeEach(() => {
    liquidState.setLevel(50) // Reset to default
  })

  test("should initialize with level 50", () => {
    expect(liquidState.getLevel()).toBe(50)
  })

  test("should set valid level", () => {
    const result = liquidState.setLevel(75)
    expect(result).toBe(true)
    expect(liquidState.getLevel()).toBe(75)
  })

  test("should reject invalid levels", () => {
    expect(liquidState.setLevel(-1)).toBe(false)
    expect(liquidState.setLevel(101)).toBe(false)
    expect(liquidState.setLevel(Number.NaN)).toBe(false)
    expect(liquidState.getLevel()).toBe(50) // Should remain unchanged
  })

  test("should round decimal levels", () => {
    liquidState.setLevel(75.7)
    expect(liquidState.getLevel()).toBe(76)
  })

  test("should update timestamp on level change", () => {
    const before = liquidState.getLastUpdate()
    setTimeout(() => {
      liquidState.setLevel(80)
      const after = liquidState.getLastUpdate()
      expect(after).toBeGreaterThan(before)
    }, 10)
  })
})
