// Estado global simples e confiável
class LiquidState {
  private level = 50
  private lastUpdate: number = Date.now()

  getLevel(): number {
    return this.level
  }

  setLevel(newLevel: number): boolean {
    if (typeof newLevel !== "number" || newLevel < 0 || newLevel > 100) {
      return false
    }
    this.level = Math.round(newLevel)
    this.lastUpdate = Date.now()
    return true
  }

  getLastUpdate(): number {
    return this.lastUpdate
  }

  getState() {
    return {
      level: this.level,
      lastUpdate: this.lastUpdate,
    }
  }
}

// Singleton instance
export const liquidState = new LiquidState()
